core.location package
=====================

Submodules
----------

core.location.event module
--------------------------

.. automodule:: core.location.event
    :members:
    :undoc-members:
    :show-inheritance:

core.location.geo module
------------------------

.. automodule:: core.location.geo
    :members:
    :undoc-members:
    :show-inheritance:

core.location.mobility module
-----------------------------

.. automodule:: core.location.mobility
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: core.location
    :members:
    :undoc-members:
    :show-inheritance:
