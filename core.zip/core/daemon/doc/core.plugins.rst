core.plugins package
====================

Submodules
----------

core.plugins.sdt module
-----------------------

.. automodule:: core.plugins.sdt
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: core.plugins
    :members:
    :undoc-members:
    :show-inheritance:
