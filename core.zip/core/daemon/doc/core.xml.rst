core.xml package
================

Submodules
----------

core.xml.corexml module
-----------------------

.. automodule:: core.xml.corexml
    :members:
    :undoc-members:
    :show-inheritance:

core.xml.corexmldeployment module
---------------------------------

.. automodule:: core.xml.corexmldeployment
    :members:
    :undoc-members:
    :show-inheritance:

core.xml.emanexml module
------------------------

.. automodule:: core.xml.emanexml
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: core.xml
    :members:
    :undoc-members:
    :show-inheritance:
