core.services package
=====================

Submodules
----------

core.services.bird module
-------------------------

.. automodule:: core.services.bird
    :members:
    :undoc-members:
    :show-inheritance:

core.services.coreservices module
---------------------------------

.. automodule:: core.services.coreservices
    :members:
    :undoc-members:
    :show-inheritance:

core.services.emaneservices module
----------------------------------

.. automodule:: core.services.emaneservices
    :members:
    :undoc-members:
    :show-inheritance:

core.services.frr module
------------------------

.. automodule:: core.services.frr
    :members:
    :undoc-members:
    :show-inheritance:

core.services.nrl module
------------------------

.. automodule:: core.services.nrl
    :members:
    :undoc-members:
    :show-inheritance:

core.services.quagga module
---------------------------

.. automodule:: core.services.quagga
    :members:
    :undoc-members:
    :show-inheritance:

core.services.sdn module
------------------------

.. automodule:: core.services.sdn
    :members:
    :undoc-members:
    :show-inheritance:

core.services.security module
-----------------------------

.. automodule:: core.services.security
    :members:
    :undoc-members:
    :show-inheritance:

core.services.ucarp module
--------------------------

.. automodule:: core.services.ucarp
    :members:
    :undoc-members:
    :show-inheritance:

core.services.utility module
----------------------------

.. automodule:: core.services.utility
    :members:
    :undoc-members:
    :show-inheritance:

core.services.xorp module
-------------------------

.. automodule:: core.services.xorp
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: core.services
    :members:
    :undoc-members:
    :show-inheritance:
