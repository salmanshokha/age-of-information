## To do  
- [ ] Implementing an interference model  
- [ ] *wmediumd*: notion of multiple wireless medium ([reference](https://groups.google.com/d/msg/mininet-wifi-discuss/AljrtpYTLhM/nwi4gYe7AQAJ))   
- [x] Adding support to Python 3 ([done with the branch dev](https://github.com/intrig-unicamp/mininet-wifi/tree/dev))     
- [ ] Replacing net-tools by iproute2 ([some inconsistency with iw has been observed](https://github.com/intrig-unicamp/mininet-wifi/commit/dd5adfb9b7786bba763f4c091f95466feec4d5d7))  
- [ ] MIMO support
