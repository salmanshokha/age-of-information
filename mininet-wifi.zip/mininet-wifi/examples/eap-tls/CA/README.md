Run gencerts.sh to generate certificates for your eap-tls example.
To clean up, run clean.sh. This will remove all generated artifacts.
