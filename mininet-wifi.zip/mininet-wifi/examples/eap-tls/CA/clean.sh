rm -f *.crl *.p7s *.crt *.key *.csr *.srl
